"""07 - Olay Analizi Katmani: paylasilan veri modelleri.

`Event Engine` (T008), `Temporal Reasoning` ve `Rule Engine` (T010) modulleri
arasinda tasinan yapilandirilmis nesneleri tanimlar. Bu katman, `04 Context
Builder` ile `05 LangGraph Agentic Loop` arasindaki ara katmandir; `src/vlm/`
ve `src/memory/` modullerine yalnizca salt-okunur tip referansi icin bakar,
onlari degistirmez.
"""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Dict, List, Optional

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from src.vlm.base_vlm import VLMResponse


class EventEngineInput(BaseModel):
    """Event Engine'e beslenen, VLM ciktisindan map'lenmis standardize girdi.

    `src/vlm/base_vlm.py` icindeki `VLMResponse` alanlarindan dogrudan
    turetilir (bkz. `from_vlm_response`); VLM katmanina hicbir degisiklik
    gerektirmez.
    """

    vlm_description: str = Field(description="VLM'in urettigi dogal dil olay aciklamasi.")
    timestamp: float = Field(description="Gozlemin saniye cinsinden zaman damgasi.")
    source_model: str = Field(description="Aciklamayi ureten VLM'in model adi.")
    frame_count: int = Field(default=0, ge=0, description="Aciklamaya kaynaklik eden Kanit Karesi sayisi.")
    structured_events: List[dict] = Field(
        default_factory=list,
        description=(
            "VLM'in dogrudan urettigi tipli olaylar (`EVENTS_JSON`); her biri "
            "`{type, timestamp, confidence, evidence}`. Bos ise EventEngine "
            "anahtar-kelime fallback'ine duser."
        ),
    )
    evidence_timestamps: Dict[str, float] = Field(
        default_factory=dict,
        description=(
            "SAFIR-specific deterministic temporal consistency validation icin: "
            "`EvidenceFrame.evidence_id -> EvidenceFrame.timestamp_sec` eslemesi "
            "(bu cagriya ait TUM evidence kareleri, `sampler`den gelen gercek "
            "zaman damgalariyla). `EventEngine._detect_from_structured`, VLM'in "
            "urettigi `start_time`/`end_time`in bu GERCEK zaman damgalariyla "
            "tutarli olup olmadigini bu esleme uzerinden dogrular - VLM'in "
            "zaman iddiasini 'duzeltmek' degil, DOGRULAMAK icindir (bkz. "
            "`EventEngine._enforce_temporal_consistency` docstring'i). Bos "
            "birakilirsa (eski davranisla uyumlu) hicbir dogrulama yapilmaz."
        ),
    )

    @classmethod
    def from_vlm_response(
        cls,
        vlm_response: "VLMResponse",
        timestamp: float,
        evidence_timestamps: Optional[Dict[str, float]] = None,
    ) -> "EventEngineInput":
        """`VLMResponse` orneginden bir `EventEngineInput` uretir.

        Args:
            vlm_response: `BaseVLM.analyze_evidence(...)`/`reconcile_events(...)` ciktisi.
            timestamp: Gozlemin zaman damgasi (orn. son evidence karesinin zaman damgasi).
            evidence_timestamps: Bkz. `EventEngineInput.evidence_timestamps`;
                `None`/bos birakilirsa zamansal tutarlilik dogrulamasi atlanir.

        Returns:
            Event Engine'e dogrudan verilebilecek girdi nesnesi.
        """
        return cls(
            vlm_description=vlm_response.description,
            timestamp=timestamp,
            source_model=vlm_response.model_name,
            frame_count=vlm_response.frame_count,
            structured_events=list(getattr(vlm_response, "structured_events", []) or []),
            evidence_timestamps=dict(evidence_timestamps or {}),
        )


class EventType(str, Enum):
    """Event Engine'in tanidigi olay kategorileri.

    Ilk 8 deger, `src/rag/embedding_rag_service.py::DEFAULT_ISG_REGULATIONS`
    icindeki 8 mevzuat maddesiyle birebir hizalanmistir (bkz.
    `EVENT_TYPE_REGULATION_MAP`); T010 Rule Engine bu eslesmeyi dogrudan
    kullanabilir. `YETKISIZ_ERISIM` ve `GENEL_GOZLEM` mevcut mevzuat setinde
    karsiligi olmayan, operasyonel amacli iki ozel kategoridir (asagida
    ayrica aciklanmistir).
    """

    DUSME_RISKI = "dusme_riski"
    """ISG Yonetmeligi Madde 12 (yukseklikte calisma / dusme onleyici ekipman)."""

    KKD_IHLALI = "kkd_ihlali"
    """ISG Yonetmeligi Madde 24 (Kisisel Koruyucu Donanim eksikligi)."""

    ARAC_YAYA_YAKINLIGI = "arac_yaya_yakinligi"
    """Operasyonel Kural OK-07 (forklift/is makinesi - yaya gecidi ihlali)."""

    SICAK_CALISMA_IHLALI = "sicak_calisma_ihlali"
    """ISG Yonetmeligi Madde 31 (izinsiz ates/kivilcim/sicak yuzey islemi)."""

    YANGIN_DUMAN = "yangin_duman"
    """Yangin Guvenligi Talimati YG-03 (duman/alev tespiti)."""

    DAR_ALAN_IHLALI = "dar_alan_ihlali"
    """ISG Yonetmeligi Madde 45 (gaz olcumu/gozetmen olmadan kapali-dar alana giris)."""

    ENERJI_KESME_IHLALI = "enerji_kesme_ihlali"
    """Operasyonel Kural OK-15 (LOTO - Lockout/Tagout prosedurune uyulmadan mudahale)."""

    AGIR_YUK_RISKI = "agir_yuk_riski"
    """ISG Yonetmeligi Madde 52 (sinyalman olmadan vinc/kren ile agir yuk kaldirma)."""

    YETKISIZ_ERISIM = "yetkisiz_erisim"
    """Mevzuat disi, operasyonel izleme kategorisi: mevcut `DEFAULT_ISG_REGULATIONS`
    setinde dogrudan karsiligi yoktur, ancak yasakli/yetkisiz alana giris
    saha guvenligi acisindan izlenmesi gereken yaygin bir durum oldugundan
    enum'da tutulur. Mevzuat seti genisledikce (orn. erisim kontrolu maddesi
    eklenirse) `EVENT_TYPE_REGULATION_MAP`'e baglanabilir."""

    GENEL_GOZLEM = "genel_gozlem"
    """Fallback kategori: hicbir kural kategorisi eslesmedigi durumlar icin (mevzuat karsiligi yok)."""

    SINIFLANDIRILAMADI = "siniflandirilamadi"
    """Siniflandirilamayan olay kategorisi: 8 temel ISG mevzuat kuralindan birine oturtulamayan riskli/anormal durumlar."""


EVENT_TYPE_REGULATION_MAP: Dict[EventType, Optional[str]] = {
    EventType.DUSME_RISKI: "ISG Yonetmeligi Madde 12",
    EventType.KKD_IHLALI: "ISG Yonetmeligi Madde 24",
    EventType.ARAC_YAYA_YAKINLIGI: "Operasyonel Kural OK-07",
    EventType.SICAK_CALISMA_IHLALI: "ISG Yonetmeligi Madde 31",
    EventType.YANGIN_DUMAN: "Yangin Guvenligi Talimati YG-03",
    EventType.DAR_ALAN_IHLALI: "ISG Yonetmeligi Madde 45",
    EventType.ENERJI_KESME_IHLALI: "Operasyonel Kural OK-15",
    EventType.AGIR_YUK_RISKI: "ISG Yonetmeligi Madde 52",
    EventType.YETKISIZ_ERISIM: None,
    EventType.GENEL_GOZLEM: None,
    EventType.SINIFLANDIRILAMADI: None,
}
"""`EventType` -> ilgili mevzuat maddesinin kisa referans etiketi.

Etiketler `src/rag/embedding_rag_service.py::DEFAULT_ISG_REGULATIONS`
icindeki tam metinlerin basliklarina karsilik gelir (o dosyaya bagimlilik
eklememek icin metin burada tekrarlanmaz, yalnizca referans etiketi
tutulur). `None` degeri, o kategorinin mevcut mevzuat setinde karsiligi
olmadigi anlamina gelir (bkz. `YETKISIZ_ERISIM`/`GENEL_GOZLEM` docstring'leri).
"""


class DetectedEvent(BaseModel):
    """Event Engine'in VLM metninden cikardigi tek bir yapilandirilmis olay.

    T020 (kimlik ayrimi): olayin BIRINCIL kimligi artik `event_name`dir - VLM'in
    KENDI urettigi, ONCEDEN TANIMLI bir taksonomiyle SINIRLI OLMAYAN serbest
    bicimli isim (orn. "yerde_hareketsiz_kisi"). `event_type`, ARTIK OPSIYONEL
    bir "canonical" baglantidir: yalnizca VLM'in gozlemi ZATEN BILINEN 11
    kategoriden (bkz. `EventType`) birine GERCEKTEN karsilik geliyorsa
    doldurulur; VLM bunu doldurmak ZORUNDA DEGILDIR. `None` ise bu, deterministik
    `RuleEngine`in bu olay icin (kasitli olarak) HICBIR RuleMatch URETMEYECEGI
    anlamina gelir - "eslesmedi" GECERLI ve BEKLENEN bir durumdur.
    """

    event_name: str = Field(
        description="Olayin BIRINCIL, serbest-bicimli kimligi (VLM-uretimi; ONCEDEN TANIMLI bir "
        "taksonomiyle SINIRLI DEGIL, orn. 'yerde_hareketsiz_kisi', 'dengesiz_malzeme_istifi')."
    )
    event_type: Optional[str] = Field(
        default=None,
        description="OPSIYONEL canonical baglanti (bkz. `EventType`); yalnizca VLM'in gozlemi ZATEN "
        "BILINEN bir kategoriye GERCEKTEN karsilik geliyorsa doldurulur. `None` = 'eslestirilemedi' "
        "(GECERLI sonuc, otomatik bir kategoriye ZORLANMAZ).",
    )
    description: str = Field(description="Olayin dogal dil aciklamasi (VLM metninden alinir).")
    timestamp: float = Field(description="Olayin (baslangic) saniye cinsinden zaman damgasi.")
    end_timestamp: Optional[float] = Field(
        default=None, description="Olayin bitis zaman damgasi (VLM'in `end_time`i); bilinmiyorsa None."
    )
    confidence: float = Field(ge=0.0, le=1.0, description="Tespitin guven skoru (0.0-1.0).")
    matched_keywords: List[str] = Field(
        default_factory=list, description="Tespiti tetikleyen anahtar kelimeler (varsa)."
    )
    source_model: Optional[str] = Field(default=None, description="Aciklamayi ureten VLM'in model adi.")
    vlm_event_id: Optional[str] = Field(
        default=None, description="VLM'in bu olaya verdigi (batch-yerel veya reconcile-sonrasi global) `event_id`."
    )
    evidence_ids: List[str] = Field(
        default_factory=list,
        description="VLM'in bu olaya atadigi `EvidenceFrame.evidence_id` listesi (bkz. `EVENTS_JSON.evidence_ids`); "
        "uydurulmus/gecersiz kimlikler `main.py` katmaninda filtrelenir.",
    )
    risk_hint: Optional[int] = Field(
        default=None,
        ge=0,
        le=100,
        description="VLM'in verdigi KABA, ipucu niteliginde risk skoru (0-100); "
        "NIHAI risk skoru degildir (bu, 05 LangGraph Ajaninin gorevidir).",
    )


class TemporalEvent(BaseModel):
    """T009 Temporal Reasoning ciktisi: zaman ekseninde gruplanmis/iliskilendirilmis olay.

    `TemporalReasoner`, ayni `event_type`e sahip ve birbirine yakin zamanli
    `DetectedEvent`leri tek bir `TemporalEvent`e (bir "suregelen olay") indirger
    (`occurrence_count > 1`, `duration > 0`); tek basina kalan `DetectedEvent`ler
    `occurrence_count == 1`, `duration == 0.0` ile birebir bir `TemporalEvent`e
    doner. `related_events`, zaman ekseninde yakin duran (ayni ya da farkli
    tipte) diger `TemporalEvent`lerin `event_id`lerini tasir.
    """

    event_id: str = Field(description="Bu `TemporalEvent`e ozgu kimlik (orn. 'evt_0').")
    event_name: str = Field(
        description="Olayin BIRINCIL, serbest-bicimli kimligi (bkz. `DetectedEvent.event_name`); "
        "gruplama ARTIK BUNA gore yapilir (`event_type`e gore DEGIL)."
    )
    event_type: Optional[str] = Field(
        default=None,
        description="OPSIYONEL canonical baglanti (bkz. `DetectedEvent.event_type`); `None` = "
        "'eslestirilemedi' (GECERLI, RuleEngine bu durumda hicbir RuleMatch URETMEZ).",
    )
    description: str = Field(description="Temsili aciklama (gruptaki en son `DetectedEvent`den alinir).")
    start_timestamp: float = Field(description="Gruptaki en erken olayin zaman damgasi (saniye).")
    end_timestamp: float = Field(description="Gruptaki en son olayin zaman damgasi (saniye).")
    duration: float = Field(
        ge=0.0, description="`end_timestamp - start_timestamp`; tek olay icin 0.0."
    )
    confidence: float = Field(
        ge=0.0, le=1.0, description="Gruptaki en yuksek guven skoru, tekrar eden tespitler icin hafifce artirilmis."
    )
    occurrence_count: int = Field(ge=1, description="Bu `TemporalEvent`e birlesen `DetectedEvent` sayisi.")
    matched_keywords: List[str] = Field(
        default_factory=list, description="Gruptaki tum tespitlerden gelen anahtar kelimelerin birlesimi."
    )
    source_model: Optional[str] = Field(default=None, description="Aciklamayi ureten VLM'in model adi.")
    related_events: List[str] = Field(
        default_factory=list,
        description="Zaman ekseninde yakin duran diger `TemporalEvent`lerin `event_id` listesi.",
    )
    evidence_ids: List[str] = Field(
        default_factory=list,
        description="Gruptaki tum `DetectedEvent.evidence_ids` degerlerinin birlesimi (tekrarsiz, ilk gorulme sirali).",
    )
    risk_hint: Optional[int] = Field(
        default=None, ge=0, le=100, description="Gruptaki en yuksek `DetectedEvent.risk_hint` (VLM ipucu, nihai degil)."
    )


class RuleMatch(BaseModel):
    """Rule Engine'in (T010) bir `TemporalEvent`e karsi eslestirdigi ISG/saha kurali.

    Iki kural turu uretir:
    - Tekli kural (deterministik mevzuat eslestirmesi): `event_type`,
      eslesen `TemporalEvent`in tipiyle birebir aynidir; `related_event_ids`
      bostur.
    - Kombinasyon kurali (bilesik ihlal, `src/event_analysis/rules/isg_rules.yaml`
      icinde tanimli): `event_type`, kuralin gerektirdigi tum tiplerin `+`
      ile birlesimidir (orn. `"kkd_ihlali+arac_yaya_yakinligi"`);
      `related_event_ids`, `source_event_id` disindaki katilimci
      `TemporalEvent.event_id`lerini tasir.
    """

    rule_id: str = Field(description="Kural kimligi (orn. 'ISG-M12' veya 'COMBO-01').")
    rule_description: str = Field(description="Kuralin kisa aciklamasi.")
    event_type: str = Field(
        description="Kuralin uygulandigi olay kategorisi; kombinasyon kurallarinda '+' ile birlesik tipler."
    )
    severity: str = Field(description="Kural ihlalinin siddet seviyesi (dusuk/orta/yuksek/kritik).")
    source_event_id: str = Field(description="Bu eslesmeyi tetikleyen `TemporalEvent.event_id`.")
    related_event_ids: List[str] = Field(
        default_factory=list,
        description="Kombinasyon kurallarinda katilan diger `TemporalEvent.event_id`leri; tekli kurallarda bos.",
    )


class StructuredEvent(BaseModel):
    """T011 Event Builder ciktisi: `TemporalEvent` + ilgili `RuleMatch`lerin birlestirilmis, nihai temsili.

    Iki hedefi ayni anda karsilar:
    - `timestamp`/`description`/`risk_score`/`risk_level`/`source_model`
      alanlari, `src/memory/event_store.py::EventStore.add_event(...)`
      imzasiyla birebir isim eslesir (bkz. `to_event_store_kwargs`);
      `risk_score`/`risk_level` bu asamada henuz bilinmez (05 LangGraph
      Ajaninin karari sonrasi doldurulur), varsayilan `None`'dir.
    - `event_type`/`confidence`/`temporal_event_id`/`related_rule_matches`
      alanlari, `05 LangGraph Agentic Loop`a giden ek baglami tasir.
    """

    # --- src/memory/event_store.py::EventStore.add_event(...) ile birebir isim eslesen alanlar ---
    timestamp: float = Field(description="Olayin saniye cinsinden zaman damgasi (`TemporalEvent.end_timestamp`).")
    description: str = Field(
        description="Insan-okunur, VLM aciklamasi + tetiklenen kural(lar)in ozetiyle birlesik metin."
    )
    risk_score: Optional[int] = Field(
        default=None, ge=0, le=100, description="Henuz bilinmiyor; 05 LangGraph Ajaninin karari sonrasi doldurulur."
    )
    risk_level: Optional[str] = Field(
        default=None, description="Henuz bilinmiyor; 05 LangGraph Ajaninin karari sonrasi doldurulur."
    )
    source_model: Optional[str] = Field(default=None, description="Aciklamayi ureten VLM'in model adi.")

    # --- 05 LangGraph Agentic Loop'a giden ek baglam alanlari ---
    event_name: str = Field(
        description="Olayin BIRINCIL, serbest-bicimli kimligi (bkz. `DetectedEvent.event_name`)."
    )
    event_type: Optional[str] = Field(
        default=None,
        description="OPSIYONEL canonical baglanti (bkz. `DetectedEvent.event_type`); `None` = 'eslestirilemedi'.",
    )
    confidence: float = Field(ge=0.0, le=1.0, description="`TemporalEvent.confidence` (tekrar-duzeltilmis guven skoru).")
    temporal_event_id: str = Field(description="Bu olayin turedigi `TemporalEvent.event_id`.")
    related_rule_matches: List[RuleMatch] = Field(
        default_factory=list, description="Bu olaya (tekli veya kombinasyon olarak) uygulanan `RuleMatch` listesi."
    )
    occurrence_count: int = Field(
        default=1, ge=1, description="`TemporalEvent.occurrence_count` (birlesen tespit sayisi)."
    )
    duration: float = Field(default=0.0, ge=0.0, description="`TemporalEvent.duration` (saniye).")
    evidence_ids: List[str] = Field(
        default_factory=list, description="`TemporalEvent.evidence_ids` (bu olaya ait evidence kareleri) passthrough."
    )
    keywords: List[str] = Field(
        default_factory=list,
        description="`TemporalEvent.matched_keywords` (VLM'in serbest-bicimli, event_type taksonomisiyle "
        "SINIRLI OLMAYAN gorsel kanit ifadeleri; bkz. `EventEngine._detect_from_structured`) passthrough. "
        "Sabit bir sayi siniri yoktur; risk KARARI DEGILDIR.",
    )

    def to_event_store_kwargs(self) -> Dict[str, object]:
        """`EventStore.add_event(...)`e dogrudan `**kwargs` olarak verilebilecek sozluk uretir.

        Izlenebilirlik duzeltmesi: onceden yalnizca 5 alan (`timestamp`/
        `description`/`risk_score`/`risk_level`/`source_model`) tasiniyordu;
        `evidence_ids`/`temporal_event_id`/`event_name`/`event_type`/
        `confidence`/`occurrence_count`/`duration`/`keywords` SQLite'a hic
        yazilmiyordu (bkz. `EventStore._TRACEABILITY_COLUMNS`). Artik bu
        alanlarin tumu de tasinir - kalici bir olay kaydinin hangi kanit
        karelerine dayandigi SONRADAN yeniden kurulabilir.

        Returns:
            `EventStore.add_event` imzasiyla birebir eslesen sozluk.
        """
        return {
            "timestamp": self.timestamp,
            "description": self.description,
            "risk_score": self.risk_score,
            "risk_level": self.risk_level,
            "source_model": self.source_model,
            "temporal_event_id": self.temporal_event_id,
            "event_name": self.event_name,
            "event_type": self.event_type,
            "confidence": self.confidence,
            "occurrence_count": self.occurrence_count,
            "duration": self.duration,
            "evidence_ids": list(self.evidence_ids),
            "keywords": list(self.keywords),
        }


