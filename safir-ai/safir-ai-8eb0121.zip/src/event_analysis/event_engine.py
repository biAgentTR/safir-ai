"""T008 - Event Engine: VLM metin ciktisindan yapilandirilmis olay tespiti.

Kategori kaynagi
-----------------
`_KEYWORD_RULES` anahtarlari `EventType` degerleridir; ilk 8 kategori
`src/rag/embedding_rag_service.py::DEFAULT_ISG_REGULATIONS` icindeki 8
mevzuat maddesiyle birebir hizalanmistir (bkz. `schemas.EVENT_TYPE_REGULATION_MAP`).
`YETKISIZ_ERISIM` ve `GENEL_GOZLEM` mevcut mevzuat setinde karsiligi olmayan,
operasyonel amacli iki ozel kategoridir (bkz. `EventType` docstring'i).

Yaklasim karsilastirmasi
-------------------------
Bu katmanin gorevi, `03 VLM` katmaninin ürettigi serbest metin aciklamayi
(`VLMResponse.description`), `05 LangGraph Agentic Loop`un tuketebilecegi
yapilandirilmis `DetectedEvent` nesnelerine cevirmek. Iki yaklasim
degerlendirildi:

1. Kural tabanli / anahtar kelime eslestirme (secilen yaklasim)
   (+) Deterministik: ayni girdi her zaman ayni ciktiyi uretir, testte
       kolayca dogrulanir.
   (+) GPU/ag bagimliligi yok; milisaniyeler icinde calisir, `02 Adaptive
       Sampler` katmaninin "CPU ONLY" felsefesiyle tutarlidir.
   (+) `05 LangGraph Ajani` zaten ayni metni bir LLM ile degerlendirip risk
       skoru uretiyor; burada ikinci bir LLM cagrisi islevsel tekrar
       olustururdu.
   (-) VLM'in ifade cesitliligine (esanlamli kelimeler, dolayli anlatim,
       olumsuzlama) karsi kirilgan; yeni olay tipleri icin manuel anahtar
       kelime bakimi gerektirir.

2. Kucuk bir LLM'e (Qwen3) siniflandirma sorusu sormak
   (+) Ifade cesitliligine karsi daha dayanikli; yeni kategori eklemek
       kod degil, prompt guncellemesi ister.
   (-) Her VLM ciktisi icin ekstra bir LLM round-trip'i: gecikme ve
       GPU/vLLM bagimliligi ekler.
   (-) Non-deterministik cikti; birim testte mutlaka mock gerektirir.
   (-) `05` katmani zaten ayni metni LLM ile degerlendiriyor; bu adimda
       ikinci bir LLM cagrisi maliyeti karsiliksiz kalir.

Karar: kural tabanli yaklasim secildi (yukaridaki (+) gerekceleriyle) ANCAK
sartname acikca "statik, yalnizca kural tabanli cozumler dusuk puanlanacaktir"
der - bu yuzden SAF kural-tabanli tasarim TEK BASINA yeterli degildir.

2026-08-25 (kucuk-LLM FALLBACK siniflandirici - T008 P1): `EventEngine.
__init__`teki `classifier` parametresi (daha once "ileride" icin ayrilmis,
KULLANILMAYAN bir genisletme noktasiydi) artik AKTIF: birincil (VLM
structured) VE ikincil (anahtar-kelime) yol HER IKISI de basarisiz olup
hicbir kategori bulamadiginda - yani sistem `genel_gozlem`e dusmek UZERE
oldugunda - bu SON ADIMDA, kucuk/hizli bir LLM'e ("llm-fast", `src.vlm.
llm_client.LLMClient` ile ayni `invoke_json(messages) -> AIMessage`
sozlesmesi) TEK bir siniflandirma sorusu sorulur (bkz. `src/prompts/
event_classifier_prompts.py`, `_classify_with_llm_fallback`). Boylece:
- Hizli/deterministik/ucretsiz yol (structured + keyword) HER ZAMAN
  ONCELIKLIDIR - bu LLM cagrisi yalnizca "hicbiri calismadi" durumunda,
  YANI EN NADIR yolda tetiklenir (gecikme/maliyet minimal).
- "Kural motoru %100 emin olamazsa otonom karar al" mantigi somutlasir -
  sartnamenin "Ajanin akil yurutme yetenegi" kriterine katki saglar.
- `classifier=None` (varsayilan, orn. mock-LLM modunda `main.py` bunu HIC
  enjekte etmez) ile davranis TAMAMEN ESKISI GIBI kalir - genel_gozlem'e
  duser; bu OPSIYONEL bir zenginlestirmedir, ZORUNLU bir bagimlilik degil.
- 2026-08-25 (2. duzeltme): siniflandirici BASARISIZ olursa (ag hatasi,
  bozuk JSON, gecersiz kategori), bu ARTIK sessizce "genel_gozlem"e (yani
  "risk yok" ONAYINA) DUSMEZ - "belirsiz/karar verilemedi" ile "onaylanmis
  risk yok" AYNI SEY DEGILDIR (`risk_status="unknown"` icin daha once
  yapilan P0 duzeltmesiyle AYNI gerekce). Basarisiz cagri, `event_type=
  None`/`event_name="degerlendirme_yapilamadi"` ile ACIKCA isaretlenen AYRI
  bir "belirsiz" olay uretir (bkz. `_indeterminate_event`) - pipeline yine
  de ASLA COKMEZ, yalnizca dogru/durust bir etiket kullanilir.

T014 - Olumsuzlama tespiti (ve sinirlari)
-------------------------------------------
Yukaridaki (-) maddesinde belirtilen "olumsuzlama" zayifligi, T013'un gercek
pipeline entegrasyonunda somut olarak gozlemlendi: `MockVLMClient`in sabit
aciklamasindaki "Herhangi bir duman veya yangin belirtisi tespit edilmedi."
cumlesi (duman/yangin OLMADIGINI soyluyor), salt substring eslestirmesiyle
`yangin_duman` olarak YANLIS POZITIF tespit ediliyordu. Bunu gidermek icin
`_is_negated()` ile basit bir kelime-penceresi sezgiseli eklendi: bir anahtar
kelime, ayni klanuz (cumle) icinde, kelimenin oncesindeki VE sonrasindaki
`_NEGATION_WINDOW_WORDS` kelime icinde `_NEGATION_CUES`'ten biri geciyorsa
"olumsuzlanmis" sayilir ve o eslesme atlanir. Pencere hem geriye hem ileriye
tarandi, cunku Turkce SOV (Ozne-Nesne-Yuklem) sozdiziminde olumsuzlama eki
genellikle klanuzun SONUNDAKI yuklemde bulunur (yukaridaki "tespit edilmedi"
ornegindeki gibi) - yalnizca geriye bakan bir pencere bu yaygin durumu
kacirirdi.

Bu, TAM bir NLP/bagimlilik ayristirma (dependency parsing) cozumu DEGILDIR;
bilinen sinirlamalari:
- Cok cumlecikli/ic ice gecmis olumsuzlamalari (orn. "X olmadigini soylemek
  yanlis olmaz" gibi cift olumsuzlama) ayirt edemez.
- Pencere disina tasan (uzun ana cumleler, ara cumlecikler) olumsuzlamalari
  kacirabilir.
- `_NEGATION_CUES` listesi kapsamli degildir; yeni olumsuzlama ifadeleri
  (esanlamlilar) elle eklenmelidir.
- Klanuz icinde AYNI anahtar kelimenin birden fazla gectigi durumlarda,
  yalnizca ILK gecislerin klanuzu kontrol edilir (`str.find` tabanli).

Bu sinirlamalar, T008'de zaten belgelenen "kural tabanli yaklasimin ifade
cesitliligine kirilganligi" zayifliginin bir devami/kismi iyilestirmesidir;
tam giderilmesi icin (2) numarali LLM-tabanli alternatif (veya gercek bir
NLP kutuphanesi) gerekir.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Optional

from langchain_core.messages import HumanMessage, SystemMessage

from src.event_analysis.schemas import DetectedEvent, EventEngineInput, EventType
from src.prompts import EVENT_CLASSIFIER_SYSTEM_PROMPT, build_event_classifier_user_prompt

logger = logging.getLogger(__name__)

_LLM_FALLBACK_SOURCE_SUFFIX = "+llm_fallback_classifier"
"""`DetectedEvent.source_model`e eklenen ek - bu olayin yapisal/keyword yolu
DEGIL, kucuk-LLM geri-dususu ile siniflandirildigini izlenebilir kilar."""

_KEYWORD_RULES: Dict[EventType, List[str]] = {
    EventType.DUSME_RISKI: [
        "dusme onleyici",
        "yukseklikte calisma",
        "guvenlik kemeri",
        "korkuluk yok",
        "iskele",
    ],
    EventType.KKD_IHLALI: [
        "baretsiz",
        "yeleksiz",
        "koruyucu ekipman eksik",
        "kkd eksik",
        "korumasiz alan",
    ],
    EventType.ARAC_YAYA_YAKINLIGI: [
        "forklift",
        "yaya gecidi",
        "arac yaklas",
        "carpisma riski",
        "yaya trafigi",
    ],
    EventType.SICAK_CALISMA_IHLALI: [
        "sicak calisma izni",
        "kaynak islemi",
        "kivilcim",
        "izinsiz ates",
    ],
    EventType.YANGIN_DUMAN: [
        "duman",
        "yangin",
        "alev",
        "yanik kokusu",
    ],
    EventType.DAR_ALAN_IHLALI: [
        "kapali alan",
        "dar alan",
        "gaz olcumu yapilmadan",
        "gozetmen olmadan",
    ],
    EventType.ENERJI_KESME_IHLALI: [
        "elektrik pano",
        "enerji kesme",
        "loto",
        "kilitleme etiketleme",
    ],
    EventType.AGIR_YUK_RISKI: [
        "vinc",
        "kren",
        "agir yuk kaldirma",
        "sinyalman olmadan",
    ],
    EventType.YETKISIZ_ERISIM: [
        "yetkisiz",
        "izinsiz giris",
        "yasakli alan",
        "guvenlik ihlali",
    ],
    EventType.SINIFLANDIRILAMADI: [
        "siniflandirilamayan",
        "tanimlanamayan risk",
        "belirsiz ihlal",
        "anormallik",
        "bilinmeyen durum",
    ],
}

_BASE_CONFIDENCE = 0.5
_CONFIDENCE_STEP_PER_EXTRA_MATCH = 0.1

# VLM'in dogrudan urettigi tipli olaylari dogrulamak icin gecerli EventType degerleri.
_VALID_EVENT_TYPES = {event_type.value for event_type in EventType}

_NEGATION_CUES: List[str] = [
    "degil",
    "yok",
    "yoktur",
    "olmadi",
    "bulunmuyor",
    "gorulmedi",
    "gozlemlenmedi",
    "gozlenmedi",
    "tespit edilmedi",
    "rastlanmadi",
]
"""Olumsuzlama ifadeleri (TR, kod tabaninin geri kalaniyla tutarli ASCII
harflerle). Kapsamli DEGILDIR; bkz. modul dokustringindeki T014 bolumu."""

_NEGATION_WINDOW_WORDS = 5
"""Bir anahtar kelimenin olumsuzlanmis sayilmasi icin, kelimenin basladigi/
bittigi konumdan ONCE ve SONRA (ayni klanuz icinde) taranacak kelime sayisi."""

_CLAUSE_SPLIT_PATTERN = re.compile(r"[.!?;]+")


def _split_into_clauses(text: str) -> List[str]:
    """Metni cumle/klanuz sinirlarina (`. ! ? ;`) gore ayri parcalara boler.

    Olumsuzlama kontrolu, bir anahtar kelimenin yalnizca KENDI klanuzu
    icindeki baglamini dikkate almalidir (baska bir cumledeki olumsuzlama
    bu kelimeyi etkilememeli).

    Args:
        text: Kucuk harfe cevrilmis VLM aciklama metni.

    Returns:
        Bos olmayan, bas/son bosluklari temizlenmis klanuz listesi. Hicbir
        ayirici bulunmazsa, tum metni tek elemanli liste olarak dondurur.
    """
    return [clause.strip() for clause in _CLAUSE_SPLIT_PATTERN.split(text) if clause.strip()]


def _is_negated(clause: str, keyword: str, window_words: int = _NEGATION_WINDOW_WORDS) -> bool:
    """Bir anahtar kelimenin, bulundugu klanuz icinde olumsuzlanip olumsuzlanmadigini kontrol eder.

    Basit bir kelime-penceresi sezgiseli kullanir: anahtar kelimenin
    basladigi kelime konumundan `window_words` kadar ONCESI ve bittigi
    konumdan `window_words` kadar SONRASI (ayni klanuz icinde) taranir; bu
    pencerede `_NEGATION_CUES`'ten biri geciyorsa anahtar kelime
    olumsuzlanmis sayilir. Bkz. modul dokustringindeki T014 bolumu icin
    bu yaklasimin (SOV sozdizimi nedeniyle iki yonlu tarama) gerekcesi ve
    bilinen sinirlamalari.

    Args:
        clause: Anahtar kelimeyi iceren, kucuk harfli klanuz metni.
        keyword: Kontrol edilecek anahtar kelime (tek veya cok kelimeli).
        window_words: Her iki yonde taranacak kelime sayisi.

    Returns:
        Pencere icinde bir olumsuzlama ifadesi geciyorsa `True`.
    """
    start_char = clause.find(keyword)
    if start_char == -1:
        return False

    words = clause.split()
    prefix_word_count = len(clause[:start_char].split())
    keyword_word_count = len(keyword.split())

    window_start = max(0, prefix_word_count - window_words)
    window_end = min(len(words), prefix_word_count + keyword_word_count + window_words)
    context = " ".join(words[window_start:window_end])

    return any(cue in context for cue in _NEGATION_CUES)


class EventEngine:
    """VLM aciklama metnini tarayip yapilandirilmis `DetectedEvent` listesi ureten katman.

    Bkz. modul dokustringi icin kural-tabanli/LLM-tabanli yaklasim
    karsilastirmasi ve secilen yaklasimin gerekcesi.
    """

    def __init__(self, classifier: Optional[Any] = None, min_confidence: float = 0.0) -> None:
        """EventEngine'i opsiyonel bir siniflandirici ve guven esigiyle baslatir.

        Args:
            classifier: `invoke_json(messages) -> AIMessage` sozlesmesine
                sahip opsiyonel bir LLM istemcisi (orn. `src.vlm.llm_client.
                LLMClient`, gercek "llm-fast" EVREN uc noktasina baglanir).
                Yalnizca birincil (VLM structured) VE ikincil (anahtar-kelime)
                yol HER IKISI de basarisiz oldugunda, SON CARE siniflandirma
                icin cagrilir (bkz. modul dokustringi 2026-08-25 notu).
                `None` (varsayilan) ile fallback TAMAMEN DEVRE DISIDIR -
                davranis eski (genel_gozlem'e duser) haliyle AYNI kalir.
            min_confidence: Bu esigin altindaki tespitler `detect()`
                ciktisindan elenir (varsayilan 0.0: hicbiri elenmez).
        """
        self._classifier = classifier
        self._min_confidence = min_confidence

    def detect(self, engine_input: EventEngineInput) -> List[DetectedEvent]:
        """VLM ciktisindan yapilandirilmis olaylar uretir (once model-tabanli, sonra anahtar-kelime).

        Oncelik sirasi:
        1. VLM dogrudan tipli olaylar urettiyse (`EVENTS_JSON`,
           `engine_input.structured_events`), bunlar dogrulanip kullanilir
           (model-tabanli siniflandirma; sartname "statik kural" cezasindan kacinir).
        2. Yapilandirilmis olay yoksa/gecersizse, mevcut anahtar-kelime kurali
           (olumsuzlama tespitiyle) FALLBACK olarak devreye girer.

        Her iki durumda da hicbir olay uretilemezse, dusuk guvenli tek bir
        `genel_gozlem` olayi dondurulur; boylece her VLM aciklamasi en az bir
        `DetectedEvent`e karsilik gelir.

        Args:
            engine_input: `EventEngineInput.from_vlm_response(...)` ile
                uretilmis, VLM aciklamasi + (varsa) tipli olaylar + zaman damgasi.

        Returns:
            Guven skoruna gore azalan sirali `DetectedEvent` listesi.
        """
        structured = self._detect_from_structured(engine_input)
        if structured:
            structured.sort(key=lambda event: event.confidence, reverse=True)
            logger.debug(
                "EventEngine: t=%.2f -> %d olay (model-tabanli/structured: %s)",
                engine_input.timestamp,
                len(structured),
                ", ".join(d.event_name for d in structured),
            )
            return structured

        text_lower = engine_input.vlm_description.lower()
        clauses = _split_into_clauses(text_lower)
        detections: List[DetectedEvent] = []

        for event_type, keywords in _KEYWORD_RULES.items():
            matched = self._match_keywords_excluding_negated(keywords, text_lower, clauses)
            if not matched:
                continue

            confidence = self._compute_confidence(matched, keywords)
            if confidence < self._min_confidence:
                continue

            detections.append(
                DetectedEvent(
                    event_name=event_type.value,
                    event_type=event_type.value,
                    description=engine_input.vlm_description,
                    timestamp=engine_input.timestamp,
                    confidence=confidence,
                    matched_keywords=matched,
                    source_model=engine_input.source_model,
                )
            )

        if not detections:
            if self._classifier is not None:
                # Siniflandirici YAPILANDIRILMIS - "genel_gozlem" ARTIK yalnizca
                # siniflandiricinin GERCEKTEN/POZITIF olarak "risk yok" dedigi
                # durumda kullanilir; siniflandirici basarisiz olursa/gecersiz
                # bir sey donerse bu, "risk yok" ile ASLA KARISTIRILMAZ - acikca
                # "degerlendirilemedi" olarak isaretlenir (bkz. `_classify_with_llm_fallback`).
                detections.append(self._classify_with_llm_fallback(engine_input))
            else:
                # Siniflandirici HIC yapilandirilmamis (bkz. `main.py`: mock-LLM
                # modunda veya operator bilerek devre disi biraktiginda) - bu,
                # ONCEDEN VAR OLAN, degismemis davranistir: hicbir siniflandirma
                # denemesi YAPILMADI, bu yuzden "genel_gozlem"e (dusuk guvenli)
                # duser. Bu, "denedik ve basarisiz olduk" ile AYNI SEY DEGILDIR.
                detections.append(
                    DetectedEvent(
                        event_name=EventType.GENEL_GOZLEM.value,
                        event_type=EventType.GENEL_GOZLEM.value,
                        description=engine_input.vlm_description,
                        timestamp=engine_input.timestamp,
                        confidence=0.0,
                        matched_keywords=[],
                        source_model=engine_input.source_model,
                    )
                )

        detections.sort(key=lambda event: event.confidence, reverse=True)
        logger.debug(
            "EventEngine: t=%.2f -> %d olay tespit edildi (%s)",
            engine_input.timestamp,
            len(detections),
            ", ".join(d.event_name for d in detections),
        )
        return detections

    def _detect_from_structured(self, engine_input: EventEngineInput) -> List[DetectedEvent]:
        """VLM'in dogrudan urettigi olaylari (`structured_events`) `DetectedEvent`e cevirir.

        T020 (kimlik ayrimi): olayin BIRINCIL kimligi artik VLM'in KENDI
        urettigi `event_name` alanidir (serbest bicimli, ONCEDEN TANIMLI bir
        taksonomiyle SINIRLI DEGIL) - `EventType` enum'unda olup olmamasi bir
        KABUL/RED kriteri DEGILDIR; hicbir olay bu yuzden ATILMAZ. `type`/
        `canonical_event_type` alani varsa VE `EventType`de GERCEKTEN
        taniniyorsa opsiyonel `event_type` (canonical baglanti) olarak
        aktarilir; taninmiyorsa veya yoksa `event_type=None` kalir (bu, KASITLI
        ve GECERLI bir "eslestirilemedi" durumudur - `siniflandirilamadi` ya da
        baska bir kategoriye ZORLANMAZ).

        Geriye uyumluluk: eski/degrade bir VLM ciktisi yalnizca `type` alanini
        (yeni `event_name`/`canonical_event_type` cifti DEGIL) uretebilir; bu
        durumda `type` degeri hem `event_name` HEM DE (gecerliyse) `event_type`
        icin kullanilir - hicbir olay bu geciste KAYBOLMAZ.

        Guven skoru 0-1 araligina kirpilir; zaman damgasi item'da yoksa
        cagrinin zaman damgasina duser. `event_id`/`evidence_ids`/`end_time`/
        `risk_score` (VLM'in olay kumeleme ciktisi - bkz.
        `src/prompts/vlm_prompts.py`) varsa aynen tasinir; hicbiri VLM
        katmaninda UYDURULMAZ, yalnizca burada oldugu gibi aktarilir (kimlik
        dogrulamasi/`unassigned` yonetimi `src/main.py` katmaninda yapilir).
        Gecerli hicbir olay yoksa bos liste doner ve cagiran (`detect`)
        anahtar-kelime fallback'ine gecer.

        Args:
            engine_input: (varsa) `structured_events` tasiyan girdi.

        Returns:
            Dogrulanmis `DetectedEvent` listesi (siralama cagirana birakilir).
        """
        detections: List[DetectedEvent] = []
        for item in engine_input.structured_events:
            if not isinstance(item, dict):
                continue

            legacy_type_raw = str(item.get("type", "")).strip().lower()
            event_name = str(item.get("event_name") or item.get("event") or item.get("event_label") or "").strip()
            if not event_name:
                # Eski/degrade cikti: yalnizca `type` var - onu HEM event_name
                # HEM (gecerliyse) canonical event_type icin kullan (kayip yok).
                event_name = legacy_type_raw
            if not event_name:
                logger.debug("Structured olay atlandi (event_name/type ikisi de bos): %r", item)
                continue

            canonical_raw = str(item.get("canonical_event_type") or legacy_type_raw or "").strip().lower()
            event_type: Optional[str] = canonical_raw if canonical_raw in _VALID_EVENT_TYPES else None

            confidence = self._coerce_confidence(item.get("confidence"))
            if confidence < self._min_confidence:
                continue

            evidence = str(item.get("description") or item.get("evidence") or "").strip() or engine_input.vlm_description
            start_time = self._coerce_timestamp(
                item.get("start_time", item.get("timestamp")), engine_input.timestamp
            )
            end_time_raw = item.get("end_time")
            end_time = self._coerce_timestamp(end_time_raw, start_time) if end_time_raw is not None else None
            evidence_ids = [str(eid) for eid in (item.get("evidence_ids") or []) if isinstance(eid, (str, int))]
            start_time, end_time = self._enforce_temporal_consistency(
                start_time, end_time, evidence_ids, engine_input.evidence_timestamps
            )
            keywords = self._normalize_free_form_keywords(item.get("keywords"))
            if not keywords and event_type is not None:
                # VLM bu olay icin `keywords` uretmediyse (eski prompt/model
                # veya bos liste) VE bir canonical `event_type` biliniyorsa,
                # guvenli bir fallback olarak sabit taksonomi-tabanli
                # cikarima duser (bkz. `_extract_keywords_for_type`). Canonical
                # tip yoksa (serbest/yeni olay) taksonomi-fallback UYGULANAMAZ
                # - bos liste kalir, hicbir terim UYDURULMAZ.
                keywords = self._extract_keywords_for_type(event_type, evidence)
            detections.append(
                DetectedEvent(
                    event_name=event_name,
                    event_type=event_type,
                    description=evidence,
                    timestamp=start_time,
                    end_timestamp=end_time,
                    confidence=confidence,
                    matched_keywords=keywords,
                    source_model=engine_input.source_model,
                    vlm_event_id=str(item.get("event_id")) if item.get("event_id") is not None else None,
                    evidence_ids=evidence_ids,
                    risk_hint=self._coerce_risk_hint(item.get("risk_score")),
                )
            )
        return detections

    def _classify_with_llm_fallback(self, engine_input: EventEngineInput) -> DetectedEvent:
        """SON CARE: birincil (structured) VE ikincil (anahtar-kelime) yol basarisiz oldugunda kucuk bir LLM'e siniflandirma sorar.

        Bkz. modul dokustringi 2026-08-25 notu. 2026-08-25 (2. duzeltme -
        "belirsiz" ile "onaylanmis risk yok" KARISTIRILMAMALI): bu metod
        ARTIK ASLA `None` DONDURMEZ VE bu metod cagrildiginda ASLA sessizce
        "genel_gozlem"e (yani "risk yok" ONAYINA) DUSMEZ. Siniflandirici
        GERCEKTEN VE ACIKCA "genel_gozlem" derse bu GECERLI, POZITIF bir
        sonuctur (`event_type="genel_gozlem"`). Ancak siniflandirici cagrisi
        BASARISIZ olursa (ag hatasi, bozuk JSON, gecersiz/bilinmeyen kategori),
        bu "risk yoktur" ANLAMINA GELMEZ - sistem sadece KARAR VEREMEDI; bu
        yuzden boyle bir durumda `event_type=None` (T020: "eslestirilemedi",
        GECERLI/BEKLENEN bir sonuc) VE `event_name="degerlendirme_yapilamadi"`
        ile acikca isaretlenen, AYRI bir "belirsiz" olay dondurulur - operator/
        rapor bunu ASLA "onaylanmis risksiz gozlem" ile KARISTIRMAZ. `event_type=
        None` oldugu icin RuleEngine bu olay icin zaten hicbir RuleMatch
        URETMEZ (mevcut, degismemis davranis - bkz. `rule_engine.py`).

        Args:
            engine_input: Structured VE keyword yolunun HER IKISININ de
                basarisiz oldugu cagriya ait girdi.

        Returns:
            Siniflandirici gecerli bir kategori dondurduyse o kategoriye ait
            bir `DetectedEvent` (bu, `genel_gozlem` OLABILIR - ama bu durumda
            POZITIF/onaylanmis bir sonuctur); siniflandirici basarisiz olursa
            `event_type=None`, `event_name="degerlendirme_yapilamadi"` olan,
            "risk yok" ile ASLA karistirilamayacak belirgin bir "belirsiz" olay.
        """
        try:
            messages = [
                SystemMessage(content=EVENT_CLASSIFIER_SYSTEM_PROMPT),
                HumanMessage(content=build_event_classifier_user_prompt(engine_input.vlm_description)),
            ]
            response = self._classifier.invoke_json(messages)
            raw_text = (response.content or "").strip()
            match = re.search(r"\{.*\}", raw_text, re.DOTALL)
            payload = json.loads(match.group(0) if match else raw_text)

            event_type_raw = str(payload.get("event_type", "")).strip().lower()
            if event_type_raw not in _VALID_EVENT_TYPES:
                logger.warning(
                    "EventEngine LLM fallback: gecersiz/bilinmeyen kategori dondurdu (%r); "
                    "'risk yok' DEGIL, 'degerlendirilemedi' olarak isaretleniyor.",
                    event_type_raw,
                )
                return self._indeterminate_event(engine_input)

            confidence = self._coerce_confidence(payload.get("confidence"), default=0.3)
            reason = str(payload.get("reason") or "").strip()
        except Exception:  # noqa: BLE001 - fallback best-effort'tur, ASLA pipeline'i KESMEZ
            logger.exception(
                "EventEngine LLM fallback siniflandirmasi basarisiz; 'risk yok' DEGIL, 'degerlendirilemedi' olarak isaretleniyor."
            )
            return self._indeterminate_event(engine_input)

        event_type = EventType(event_type_raw)
        keywords = self._extract_keywords_for_type(event_type_raw, engine_input.vlm_description)
        logger.info(
            "EventEngine LLM fallback: t=%.2f -> %s (confidence=%.2f, gerekce=%s)",
            engine_input.timestamp,
            event_type_raw,
            confidence,
            reason or "(yok)",
        )
        return DetectedEvent(
            event_name=event_type.value,
            event_type=event_type.value,
            description=engine_input.vlm_description,
            timestamp=engine_input.timestamp,
            confidence=confidence,
            matched_keywords=keywords,
            source_model=f"{engine_input.source_model}{_LLM_FALLBACK_SOURCE_SUFFIX}",
        )

    @staticmethod
    def _indeterminate_event(engine_input: EventEngineInput) -> DetectedEvent:
        """Siniflandirici BASARISIZ oldugunda (hata/bozuk JSON/gecersiz kategori) dondurulen, "risk YOK" ile ASLA karistirilmayan belirsiz olay.

        `event_type=None` (T020: "eslestirilemedi" - GECERLI/BEKLENEN bir
        sonuc, RuleEngine bunun icin hicbir RuleMatch URETMEZ) VE `event_name
        ="degerlendirme_yapilamadi"` (sabit taksonomi disi, serbest bicimli
        bir isim - bkz. `DetectedEvent.event_name` docstring'i) ile, sistemin
        bu gozlem icin GERCEKTEN bir karar VEREMEDIGINI acikca isaretler.
        """
        return DetectedEvent(
            event_name="degerlendirme_yapilamadi",
            event_type=None,
            description=engine_input.vlm_description,
            timestamp=engine_input.timestamp,
            confidence=0.0,
            matched_keywords=[],
            source_model=f"{engine_input.source_model}{_LLM_FALLBACK_SOURCE_SUFFIX}_failed",
        )

    @staticmethod
    def _coerce_risk_hint(value: Any) -> Optional[int]:
        """VLM'in kaba `risk_score` ipucunu 0-100 araligina kirpilmis bir int'e cevirir (gecersizse `None`)."""
        try:
            risk = int(round(float(value)))
        except (TypeError, ValueError):
            return None
        return max(0, min(100, risk))

    @staticmethod
    def _coerce_confidence(value: Any, default: float = 0.5) -> float:
        """Guven skorunu 0.0-1.0 araligina kirpilmis bir float'a cevirir (gecersizse `default`)."""
        try:
            confidence = float(value)
        except (TypeError, ValueError):
            return default
        return round(max(0.0, min(1.0, confidence)), 2)

    @staticmethod
    def _coerce_timestamp(value: Any, fallback: float) -> float:
        """Zaman damgasini float'a cevirir; gecersizse cagrinin zaman damgasina (`fallback`) duser."""
        try:
            return float(value)
        except (TypeError, ValueError):
            return fallback

    @staticmethod
    def _enforce_temporal_consistency(
        start_time: float,
        end_time: Optional[float],
        evidence_ids: List[str],
        evidence_timestamps: Dict[str, float],
    ) -> "tuple[float, Optional[float]]":
        """SAFIR-specific deterministic temporal consistency validation.

        VLM'in `EVENTS_JSON.start_time`/`end_time` alanlari kendi urettigi
        degerlerdir (bkz. `vlm_prompts.py`: VLM'e bunlari atadigi evidence
        karelerinin GERCEK zaman damgalarindan turetmesi SOYLENIR, ama bu
        hicbir yerde koda DOGRULANMAZ). Bu, SEASON (arXiv:2512.04643)
        makalesinin decode-ici, attention-tabanli kontrastif mekanizmasinin
        bir implementasyonu DEGILDIR (o mekanizma, barindirilan bir API
        uzerinden erisilemez); yalnizca SAFIR'e ozgu, tamamen deterministik,
        kod-tarafi bir tutarlilik dogrulamasidir.

        Degismez (invariant): bir olayin span'i `T_event = [t_start, t_end]`,
        kendisine atanan evidence karelerinin gercek zaman damgalari
        `T_e = {t_1, ..., t_n}` icin
            t_start <= min(T_e)  ve  t_end >= max(T_e)
        kosulunu SAGLAMALIDIR - yani olay araligi, dayandigi TUM kanitlari
        kapsamalidir. Ihlal edilirse, VLM'in iddiasi SILINMEZ; yalnizca bu
        degismezi saglayacak sekilde GENISLETILIR (guvenli, minimal
        duzeltme - bkz. gorev tanimi: "amac VLM timestamp'ini 'duzeltmek'
        degil, dogrulamaktir" - burada duzeltme yalnizca ihlal durumunda,
        span'i DARALTMADAN, yalnizca genisleterek yapilir).

        Args:
            start_time: VLM'in urettigi (veya cagri zaman damgasina dusmus) baslangic.
            end_time: VLM'in urettigi bitis (varsa).
            evidence_ids: Bu olaya atanan evidence kimlikleri (henuz
                `main.py::_reconcile_unassigned_evidence` ile dogrulanmamis
                olabilir - bilinmeyen kimlikler asagida sessizce yoksayilir).
            evidence_timestamps: `EventEngineInput.evidence_timestamps`
                (evidence_id -> gercek zaman damgasi). Bos ise (cagiran
                bunu hic saglamadiysa) VLM'in zaman iddiasi TAMAMEN kopuk
                sayilir ve dogrulama atlanir - guvenli fallback, mevcut
                deger degistirilmeden aynen dondurulur.

        Returns:
            `(start_time, end_time)` - ihlal yoksa GIRDIYLE BIREBIR AYNI;
            ihlal varsa yalnizca degismezi saglayacak minimal genisletme
            uygulanmis hali. `start_time <= end_time` de her zaman saglanir
            (end_time varsa).
        """
        # Evidence'dan tamamen bagimsiz, kosulsuz invariant: start <= end.
        # VLM start_time > end_time gibi gecersiz bir span uretirse (evidence
        # eslemesi olsun ya da olmasin), bu asla asagi akisa (duration
        # hesabina) negatif olarak sizmamalidir.
        if end_time is not None and end_time < start_time:
            end_time = start_time

        known_timestamps = [
            evidence_timestamps[eid] for eid in evidence_ids if eid in evidence_timestamps
        ]
        if not known_timestamps:
            # Evidence'dan tamamen kopuk (bilinen hicbir evidence_id yok) -
            # guvenli fallback: VLM'in iddiasina (start<=end disinda) dokunma.
            return start_time, end_time

        evidence_min = min(known_timestamps)
        evidence_max = max(known_timestamps)

        corrected_start = min(start_time, evidence_min)
        # end_time VLM tarafindan hic verilmediyse (None) bu "bilinmiyor"
        # demektir - bir deger UYDURULMAZ, None oldugu gibi kalir. Yalnizca
        # VLM zaten bir end_time VERMISSE ve bu, evidence'in gercek ust
        # sinirinin ALTINDA kalmissa genisletilir.
        corrected_end = max(end_time, evidence_max) if end_time is not None else None
        if corrected_end is not None and corrected_end < corrected_start:
            corrected_end = corrected_start

        if corrected_start != start_time or corrected_end != end_time:
            logger.warning(
                "EventEngine: VLM start_time/end_time (%.2f/%s) atadigi evidence "
                "karelerinin gercek zaman araligini (%.2f-%.2f) kapsamiyordu; "
                "SAFIR-specific deterministic temporal consistency validation "
                "geregi span genisletildi -> (%.2f/%s).",
                start_time,
                end_time,
                evidence_min,
                evidence_max,
                corrected_start,
                corrected_end,
            )
        return corrected_start, corrected_end

    @staticmethod
    def _normalize_free_form_keywords(raw: Any) -> List[str]:
        """VLM'in `EVENTS_JSON.keywords` alaninda urettigi SERBEST BICIMLI (taksonomiyle SINIRLI OLMAYAN) terimleri temizler.

        Bu, `_extract_keywords_for_type`in TERSIDIR: orada sabit bir kelime
        dagarcigi metne karsi ARANIR; burada VLM'in KENDI urettigi terimler
        yalnizca bicimsel olarak (tur/bosluk/tekrar) temizlenir - hicbir
        terim baska bir listeyle KARSILASTIRILMAZ, ELENMEZ veya UYDURULMAZ.
        Sabit bir sayi siniri YOKTUR (bkz. mimari karar: EventType = kategori,
        keywords = o olaya ozgu serbest kanit).

        Args:
            raw: `item.get("keywords")` (beklenen: string listesi; VLM
                bozuk/eksik bir deger dondurebilir - bu durumda bos liste).

        Returns:
            Bos olmayan, bas/son bosluklari temizlenmis, ilk-gorulme sirali
            tekrarsiz (tam-esitlik) terim listesi. `raw` liste degilse veya
            bos ise bos liste.
        """
        if not isinstance(raw, list):
            return []

        seen: List[str] = []
        for item in raw:
            if not isinstance(item, str):
                continue
            cleaned = item.strip()
            if not cleaned or cleaned in seen:
                continue
            seen.append(cleaned)
        return seen

    @staticmethod
    def _extract_keywords_for_type(event_type: str, description: str) -> List[str]:
        """VLM'in yapilandirilmis (`EVENTS_JSON`) olayindaki serbest metin aciklamadan canonical anahtar kelime cikarir.

        Model-tabanli (structured) path daha once `matched_keywords=[]`
        birakiyordu (yalnizca `type` alani vardi); bu, `TemporalReasoner`in
        kelime birlestirmesini ve `RuleEngine`in kombinasyon kurallarini
        zayiflatiyordu. Bu metod, ayni `_KEYWORD_RULES` canonical listesini
        (anahtar-kelime fallback'inde zaten kullanilan, gercek VLM
        ciktilarindan derlenmis kelime dagarcigi) olayin kendi `event_type`ina
        karsi calistirarak VLM'in farkli ifadelerini ayni canonical kelimeye
        indirger (normalizasyon); olumsuzlanmis gecisler `_is_negated` ile
        elenir (bkz. T014).

        Args:
            event_type: `DetectedEvent.event_type` (VLM'in verdigi tip).
            description: Bu olaya ait serbest metin aciklama.

        Returns:
            Eslesen canonical anahtar kelime listesi (bulunamazsa bos liste;
            `EventType`e karsilik gelen bir `_KEYWORD_RULES` girdisi yoksa da bos).
        """
        keywords = _KEYWORD_RULES.get(EventType(event_type)) if event_type in _VALID_EVENT_TYPES else None
        if not keywords:
            return []

        text_lower = description.lower()
        clauses = _split_into_clauses(text_lower)
        return EventEngine._match_keywords_excluding_negated(keywords, text_lower, clauses)

    @staticmethod
    def _match_keywords_excluding_negated(
        keywords: List[str], text_lower: str, clauses: List[str]
    ) -> List[str]:
        """Metinde gecen ama olumsuzlanmamis anahtar kelimeleri dondurur (bkz. T014, `_is_negated`).

        Args:
            keywords: Bu kategori icin tanimli anahtar kelime listesi.
            text_lower: Kucuk harfli tam VLM aciklamasi (hizli on-filtre icin).
            clauses: `text_lower`in klanuzlara bolunmus hali.

        Returns:
            Metinde gecen VE olumsuzlanmamis anahtar kelimelerin listesi
            (orijinal `keywords` sirasi korunur).
        """
        matched: List[str] = []
        for keyword in keywords:
            if keyword not in text_lower:
                continue

            containing_clause = next((clause for clause in clauses if keyword in clause), None)
            if containing_clause is not None and _is_negated(containing_clause, keyword):
                continue

            matched.append(keyword)
        return matched

    @staticmethod
    def _compute_confidence(matched: List[str], keywords: List[str]) -> float:
        """Eslesen anahtar kelime sayisina gore basit, deterministik bir guven skoru hesaplar.

        Args:
            matched: Metinde bulunan anahtar kelimeler.
            keywords: Bu kategori icin tanimli tum anahtar kelimeler.

        Returns:
            0.0-1.0 araliginda, tek eslesme icin `_BASE_CONFIDENCE`'tan
            baslayip her ek eslesme icin `_CONFIDENCE_STEP_PER_EXTRA_MATCH`
            artan, 1.0'da tavanlanan bir skor.
        """
        extra_matches = len(matched) - 1
        confidence = _BASE_CONFIDENCE + extra_matches * _CONFIDENCE_STEP_PER_EXTRA_MATCH
        return round(min(1.0, confidence), 2)


if __name__ == "__main__":
    # T008'in bagimsiz calistirilabilirlik testi:
    #   python -m src.event_analysis.event_engine
    logging.basicConfig(level=logging.INFO)

    demo_input = EventEngineInput(
        vlm_description=(
            "Sahada bir personel korumasiz alanda, baretsiz calisiyor. Yakin "
            "cevrede forklift bir yaya gecidine yaklasiyor."
        ),
        timestamp=12.4,
        source_model="demo-vlm",
        frame_count=1,
    )
    demo_events = EventEngine().detect(demo_input)
    for demo_event in demo_events:
        print(
            f"[{demo_event.event_name} / canonical={demo_event.event_type}] conf={demo_event.confidence} "
            f"keywords={demo_event.matched_keywords}"
        )
